import Classes.Config;
import Classes.Session;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Session session = new Session();
		System.out.print(Config.WELCOME);

		int option;

		do {
			//para sesion iniciada
			if (session.isLogged()) {
				registeredMenu();
				option = sc.nextInt();
				sc.nextLine();
				optionRegistered(option, session, sc);
			//para sesion no iniciada	
			} else {
				unregisteredMenu();
				option = sc.nextInt();
				sc.nextLine();
				optionUnregistered(option, session, sc);
			}

		} while (option != 0);
		System.out.print(Config.GOODBYE);
		sc.close();
	}
	//Mostrar menu de usuario registrado
	private static void registeredMenu() {
		System.out.println(Config.LOGGED_MENU);
		System.out.print("Seleccione una opcion: ");
	}
	//Opciones del menu registrado
	private static void optionRegistered(int option, Session session, Scanner sc) {
		switch (option) {
		case 1:
		case 2:
		case 3:
		case 4:
			System.out.println("PROXIMAMENTE");
			break;
		case 5:
			session.showUser();
			break;
		case 6:
			session.logout();
			break;
		case 0:
			break;
		default:
			System.out.println("Opcion no valida");
		}
	}
	//Mostrar menu de usuarios no registrados aun
	private static void unregisteredMenu() {
		System.out.println(Config.UNLOGGED_MENU);
		System.out.print("Seleccione una opcion: ");
	}
	//Opciones para el menu de usuarios no registrados aun
	private static void optionUnregistered(int option, Session session, Scanner sc) {
		switch (option) {
		case 1:
			session.login(sc);
			break;
		case 2:
			session.signup(sc);
			break;
		case 0:
			break;
		default: 
			System.out.println("Opcion no valida");
		}
	}
}
