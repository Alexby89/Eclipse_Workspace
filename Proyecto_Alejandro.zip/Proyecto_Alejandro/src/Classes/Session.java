package Classes;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Session {

	private User user;
	private  boolean logged;
	private final String FILE_PATH = "./assets/files";
	private final String USERS_FILE = "./assets/files/users.txt";

	// CONSTRUCTOR
	public Session() {
		this.logged = false;
		this.user = null;
	}

	// LOGIN (para usuarios registrados)
	public void login(Scanner sc) {
	    System.out.print("Usuario: ");
	    String username = sc.nextLine().trim();

	    System.out.print("Contraseña: ");
	    String password = sc.nextLine().trim();

	    try {
	        File file = new File(USERS_FILE);
	        Scanner fileScanner = new Scanner(file);

	        while (fileScanner.hasNextLine()) {
	            String line = fileScanner.nextLine();
	            String[] data = line.split(";");

	            // Comprobamos que la línea tenga todos los datos
	            if (data.length >= 7) {
	                String fileUsername = data[0].trim();
	                String filePassword = data[1].trim();

	                if (fileUsername.equals(username) && filePassword.equals(password)) {
	                    this.user = new User(
	                        fileUsername,
	                        data[2].trim(),
	                        data[3].trim(),
	                        data[4].trim(),
	                        data[5].trim(),
	                        data[6].trim(),
	                        "user"
	                    );
	                    this.logged = true;
	                    System.out.println("Sesión iniciada con éxito");
	                    fileScanner.close();
	                    return;
	                }
	            }
	        }

	        fileScanner.close();
	        System.out.println("Usuario o contraseña incorrectos");

	    } catch (Exception e) {
	        System.out.println("Error al leer el archivo");
	    }
	}


	// REGISTRO (para registrar nuevos usuarios)
	public void signup(Scanner sc) {
		System.out.print("Nuevo usuario: ");
		String username = sc.nextLine();

		System.out.print("Contraseña: ");
		String password = sc.nextLine();
		
		System.out.print("Nombre completo: ");
		String name = sc.nextLine();

		System.out.print("NIF: ");
		String nif = sc.nextLine();
		
		System.out.print("Email: ");
		String email = sc.nextLine();

		System.out.print("Direccion: ");
		String address = sc.nextLine();
		
		System.out.print("Fecha de nacimiento: ");
		String birthdate = sc.nextLine();

		if (userExists(username)) {
			System.out.println("Usuario ya existente");
			return;
		}

		try {
			FileWriter writer = new FileWriter(USERS_FILE, true);
			writer.write(username + ";" + password + ";" + name + ";" + nif + ";" + email + ";" + address + ";" + birthdate + "\n");
			writer.close();
			System.out.println("El usuario fue registrado correctamente");
		} catch (IOException e) {
			System.out.println("Error al escribir en el archivo");
		}
	}

	// Comprobar si hay alguna sesion iniciada
	public boolean isLogged() {
		return this.logged;
	}

	// Mostrar usuarios que estamos usando ahora mismo
	public void showUser() {
		if (logged && user != null) {
			System.out.println("Usuario conectado:");
			System.out.println("Username: " + user.getUsername());
			System.out.println("Nombre: " + user.getName());
			System.out.println("NIF: " + user.getNif());
			System.out.println("Email: " + user.getEmail());
			System.out.println("Direccion: " + user.getAddress());
			System.out.println("Fecha de nacimiento: " + user.getBirthdate());
			System.out.println("Role: " + user.getRole());
		} else {
			System.out.println("No hay ninguna sesión iniciada");
		}
	}

	// LOGOUT (cerrar sesion)
	public void logout() {
		this.logged = false;
		this.user = null;
		System.out.println("Sesión cerrada. Esperamos volver a verle pronto");
	}

	// Metodo privado para comprobar si el usuario existe
	private boolean userExists(String username) {
		try {
			File file = new File(USERS_FILE);
			Scanner fileScanner = new Scanner(file);

			while (fileScanner.hasNextLine()) {
				String line = fileScanner.nextLine();
				String[] data = line.split(";");
				if (data[0].equals(username)) {
					fileScanner.close();
					return true;
				}
			}

			fileScanner.close();

		} catch (Exception e) {
			return false;
		}

		return false;
	}

	public String getFILE_PATH() {
		return FILE_PATH;
	}

}
